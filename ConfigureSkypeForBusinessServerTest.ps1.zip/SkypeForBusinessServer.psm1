﻿function DisableLoopbackCheck
{
    # See KB896861 for more information about why this is necessary.
    Write-Verbose -Message "Disabling Loopback Check ..."
    New-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa -Name 'DisableLoopbackCheck' -value '1' -PropertyType dword -Force | Out-Null
}

function LoadConfiguration
{
    param
    (
        [parameter(Mandatory)]
        [string] $Configuration
    )
    try 
    {
        Write-Verbose 'Loading Configuration....'

        $Script:Configuration = ConvertFrom-Json $Configuration

        foreach ($role in $Script:Configuration.roles)
        {
            if ($role.type -eq 'application')
            {
                $Script:ApplicationServerConfig = $role
            }
            elseif ($role.type -eq 'web')
            {
                $Script:WebServerConfig = $role
            }
            else
            {
                Write-Verbose -Message "Unsupported role type '$($role.type)' detected in configuration."
            }
        }

        Write-Verbose 'Finished Loading Configuration'
    }
    catch
    {
        Write-Warning ("Error:" + $_)
        throw 'Error Loading Configuration'
    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}
Export-ModuleMember -function *
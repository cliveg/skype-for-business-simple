#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSkypeForBusinessServer
{
	
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [parameter(Mandatory)]
        [String]$DatabaseServer,
      
        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60

			#region Variables


    )
		Enable-CredSSPNTLM -DomainName $DomainName

        Write-Verbose "AzureExtensionHandler loaded continuing with configuration"

        [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)


        Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xDisk, xCredSSP, cDisk, xNetworking
		Import-DscResource -ModuleName xSystemSecurity -Name xIEEsc
		Import-DscResource -ModuleName xSystemSecurity -Name xUAC
	    
        Node localhost
        {
            
            xCredSSP Server 
            { 
                Ensure = "Present" 
                Role = "Server" 
            } 
            xCredSSP Client 
            { 
                Ensure = "Present" 
                Role = "Client" 
                DelegateComputers = "*.$Domain", "localhost"
            }
            WindowsFeature ADPS
            {
                Name = "RSAT-AD-PowerShell"
                Ensure = "Present"
                DependsOn = "[cDiskNoRestart]SPDataDisk"
            }
            WindowsFeature NET-Framework-Core
            {
                Name = "NET-Framework-Core"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]ADPS"
            }
            WindowsFeature Web-Static-Content
            {
                Name = "Web-Static-Content"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]ADPS"
            }
            WindowsFeature Web-Default-Doc
            {
                Name = "Web-Default-Doc"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Static-Content"
            }
            WindowsFeature Web-Http-Errors
            {
                Name = "Web-Http-Errors"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Default-Doc"
            }
            WindowsFeature Web-Asp-Net
            {
                Name = "Web-Asp-Net"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Errors"
            }
            WindowsFeature Web-Net-Ext
            {
                Name = "Web-Net-Ext"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Asp-Net"
            }
            WindowsFeature Web-ISAPI-Ext
            {
                Name = "Web-ISAPI-Ext"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Net-Ext"
            }
            WindowsFeature Web-ISAPI-Filter
            {
                Name = "Web-ISAPI-Filter"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-ISAPI-Ext"
            }
            WindowsFeature Web-Http-Logging
            {
                Name = "Web-Http-Logging"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-ISAPI-Filter"
            }
            WindowsFeature Web-Log-Libraries
            {
                Name = "Web-Log-Libraries"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Logging"
            }
            WindowsFeature Web-Request-Monitor
            {
                Name = "Web-Request-Monitor"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Log-Libraries"
            }
            WindowsFeature Web-Http-Tracing
            {
                Name = "Web-Http-Tracing"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Request-Monitor"
            }
            WindowsFeature Web-Basic-Auth
            {
                Name = "Web-Basic-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Tracing"
            }
            WindowsFeature Web-Windows-Auth
            {
                Name = "Web-Windows-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Basic-Auth"
            }
            WindowsFeature Web-Client-Auth
            {
                Name = "Web-Client-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Windows-Auth"
            }
            WindowsFeature Web-Filtering
            {
                Name = "Web-Filtering"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Client-Auth"
            }
            WindowsFeature Web-Stat-Compression
            {
                Name = "Web-Stat-Compression"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Filtering"
            }
            WindowsFeature Web-Dyn-Compression
            {
                Name = "Web-Dyn-Compression"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Stat-Compression"
            }
            WindowsFeature NET-WCF-HTTP-Activation45
            {
                Name = "NET-WCF-HTTP-Activation45"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Dyn-Compression"
            }
            WindowsFeature Web-Asp-Net45
            {
                Name = "Web-Asp-Net45"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]NET-WCF-HTTP-Activation45"
            }
            WindowsFeature Web-Mgmt-Tools
            {
                Name = "Web-Mgmt-Tools"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Asp-Net45"
            }
            WindowsFeature Web-Scripting-Tools
            {
                Name = "Web-Scripting-Tools"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Mgmt-Tools"
            }
            WindowsFeature Web-App-Dev
            {
                Name = "Web-App-Dev"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Scripting-Tools"
            }
            WindowsFeature Web-Common-Http
            {
                Name = "Web-Common-Http"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-App-Dev"
            }
            WindowsFeature Web-Performance
            {
                Name = "Web-Performance"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Common-Http"
            }
			WindowsFeature Web-Includes
            {
                Name = "Web-Includes"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Performance"
            }
			WindowsFeature InkandHandwritingServices
            {
                Name = "InkandHandwritingServices"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Performance"
            }
			WindowsFeature NET-Framework-Features
            {
                Name = "NET-Framework-Features"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]InkandHandwritingServices"
            }
			WindowsFeature NET-HTTP-Activation
            {
                Name = "NET-HTTP-Activation"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]InkandHandwritingServices"
            }
			WindowsFeature NET-Non-HTTP-Activ
            {
                Name = "NET-Non-HTTP-Activ"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]NET-HTTP-Activation"
            }
            xWaitForADDomain DscForestWait 
            { 
                DomainName = $DomainName 
                DomainUserCredential= $DomainCreds
                RetryCount = $RetryCount 
                RetryIntervalSec = $RetryIntervalSec 
                DependsOn = "[WindowsFeature]NET-Non-HTTP-Activ"      
            }
            xComputer DomainJoin
            {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait" 
            }


#New
	Script ConfigureCPU
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={

		  # Set PowerPlan to "High Performance"
			$guid = (Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "ElementName='High Performance'").InstanceID.ToString()
			$regex = [regex]"{(.*?)}$"
			$plan = $regex.Match($guid).groups[1].value
			powercfg -S $plan
		}
	}

			xIEEsc EnableIEEscAdmin
			{
				IsEnabled = $True
				UserRole  = "Administrators"
			}

			xIEEsc EnableIEEscUser
			{
				IsEnabled = $False
				UserRole  = "Users"
			}

        xUAC NeverNotifyAndDisableAll 
        { 
            Setting = "NeverNotifyAndDisableAll" 
        } 


   #script block to download apps and install them
    Script DownloadOfficeWebAppsServer
    {
        GetScript = {
            @{
                Result = "DownloadOfficeWebAppsServer"
            }
        }
        TestScript = {
            Test-Path "C:\WindowsAzure\wacserver.img"
        }
        SetScript ={
            $source = "http://download.microsoft.com/download/7/7/F/77F250DC-F7A3-47AF-8B20-DDA8EE110AB4/wacserver.img"
            $destination = "C:\WindowsAzure\wacserver.img"
            Invoke-WebRequest $source -OutFile $destination
			# Mount ISO
            $destination = "C:\WindowsAzure\wacserver.img"
			$mount =  Mount-DiskImage -ImagePath $destination
        }
    }

	Script DownloadOfficeWebAppsEnglishLanguage
    {
        GetScript = {
            @{
                Result = "DownloadOfficeWebAppsEnglishLanguage"
            }
        }
        TestScript = {
            Test-Path "C:\WindowsAzure\wacserverlanguagepack.exe"
        }
        SetScript ={
            $source = "http://download.microsoft.com/download/5/2/B/52B01E04-313A-4F40-A858-16CE36BBDF98/wacserverlanguagepack.exe"
            $destination = "C:\WindowsAzure\wacserverlanguagepack.exe"
            Invoke-WebRequest $source -OutFile $destination
        }
    }

    Script DownloadOfficeWebAppsJanuaryCU
    {
        GetScript = {
            @{
                Result = "DownloadOfficeWebAppsJanuaryCU"
            }
        }
        TestScript = {
            Test-Path "C:\WindowsAzure\wacserver2013-kb2956101-fullfile-x64-glb.exe"
        }
        SetScript ={
            $source = "http://download.microsoft.com/download/C/A/0/CA0DD4D4-B593-477F-A3A7-241CF5E57856/wacserver2013-kb2956101-fullfile-x64-glb.exe"
            $destination = "C:\WindowsAzure\wacserver2013-kb2956101-fullfile-x64-glb.exe"
            Invoke-WebRequest $source -OutFile $destination

        }
    }


    Package OfficeWebAppsServer_Installation
        {
            Ensure = "Present"
            Name = "Office Web Apps Server"
            Path = (Get-DiskImage -ImagePath "wacserver.img" | Get-Volume).DriveLetter + ":\setup.exe"
            ProductId = '90150000-1151-0000-1000-0000000FF1CE'
            Arguments = '/config files\setupsilent\config.xml'
        }
    Package OfficeWebAppsServerLangPack_Extract
        {
            Ensure = "Present"
            Name = "Office Web Apps Server English Lang Pack Extract"
            Path = "C:\WindowsAzure\wacserverlanguagepack.exe"
            ProductId = '90150000-1157-0409-1000-0000000FF1CE'
            Arguments = '/extract:C:\WindowsAzure\OWASLanguagePacks\English /quiet'
        }
    Package OfficeWebAppsServerLangPack_Installation
        {
            Ensure = "Present"
            Name = "Office Web Apps Server English Lang Pack Install"
            Path = "C:\WindowsAzure\OWASLanguagePacks\English\setup.exe"
            ProductId = '90150000-1157-0409-1000-0000000FF1CE'
            Arguments = '/config files\setupsilent\config.xml'
        }
		Script RestartOWAS
		{
			GetScript = {
				@{
					Result = ""
				}
			}
			TestScript = {
				$false
			}
            SetScript = ([String]{            
 
			Stop-Service WACSM
			Start-Service WACSM
			
			})
			
		}
    Package OfficeWebAppsServerCU_Installation
        {
            Ensure = "Present"
            Name = "Office Web Apps Server CU"
            Path = "C:\WindowsAzure\wacserver2013-kb2956101-fullfile-x64-glb.exe"
            ProductId = '19704308-6DC4-4C0A-BBAE-FA2498AFC0A9'
            Arguments = '/q'
        }
			

#            LocalConfigurationManager 
#            {
#              ActionAfterReboot = 'StopConfiguration'
#            }
        }  
}

function Enable-CredSSPNTLM
{ 
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )
    
    # This is needed for the case where NTLM authentication is used

    Write-Verbose 'STARTED:Setting up CredSSP for NTLM'
   
    Enable-WSManCredSSP -Role client -DelegateComputer localhost, *.$DomainName -Force -ErrorAction SilentlyContinue
    Enable-WSManCredSSP -Role server -Force -ErrorAction SilentlyContinue

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows -Name '\CredentialsDelegation' -ErrorAction SilentlyContinue
    }

    if( -not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'ConcatenateDefaults_AllowFreshNTLMOnly' -value '1' -PropertyType dword -ErrorAction SilentlyContinue
    }

    if(-not (Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -ErrorAction SilentlyContinue))
    {
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name 'AllowFreshCredentialsWhenNTLMOnly' -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '1' -value "wsman/$env:COMPUTERNAME" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '2' -value "wsman/localhost" -PropertyType string -ErrorAction SilentlyContinue
    }

    if (-not (Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -ErrorAction SilentlyContinue))
    {
        New-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name '3' -value "wsman/*.$DomainName" -PropertyType string -ErrorAction SilentlyContinue
    }

    Write-Verbose "DONE:Setting up CredSSP for NTLM"
}


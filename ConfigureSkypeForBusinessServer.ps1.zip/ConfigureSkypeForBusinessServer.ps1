#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSkypeForBusinessServer
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [parameter(Mandatory)]
        [String]$DatabaseServer,
      
        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )

        Write-Verbose "AzureExtensionHandler loaded continuing with configuration"

        [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)


        # Install Skype For Business Module
        $ModuleFilePath="$PSScriptRoot\SkypeForBusiness.psm1"
        $ModuleName = "SharepointServer"
        $PSModulePath = $Env:PSModulePath -split ";" | Select -Index 1
        $ModuleFolder = "$PSModulePath\$ModuleName"
        if (-not (Test-Path  $ModuleFolder -PathType Container)) {
            mkdir $ModuleFolder
        }
        # Copy-Item $ModuleFilePath $ModuleFolder -Force

        Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xDisk, xCredSSP, cDisk, xNetworking
    
        Node localhost
        {
            
            xWaitforDisk Disk2
            {
                DiskNumber = 2
                RetryIntervalSec =$RetryIntervalSec
                RetryCount = $RetryCount
            }
            cDiskNoRestart SPDataDisk
            {
                DiskNumber = 2
                DriveLetter = "F"
                DependsOn = "[xWaitforDisk]Disk2"
            }
            xCredSSP Server 
            { 
                Ensure = "Present" 
                Role = "Server" 
            } 
            xCredSSP Client 
            { 
                Ensure = "Present" 
                Role = "Client" 
                DelegateComputers = "*.$Domain", "localhost"
            }
            WindowsFeature ADPS
            {
                Name = "RSAT-AD-PowerShell"
                Ensure = "Present"
                DependsOn = "[cDiskNoRestart]SPDataDisk"
            }
            WindowsFeature NET-Framework-Core
            {
                Name = "NET-Framework-Core"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]ADPS"
            }
            WindowsFeature RSAT-ADDS
            {
                Name = "RSAT-ADDS"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]NET-Framework-Core"
            }
            WindowsFeature RSAT-DNS-SERVER
            {
                Name = "RSAT-DNS-SERVER"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]RSAT-ADDS"
            }
            WindowsFeature Windows-Identity-Foundation
            {
                Name = "Windows-Identity-Foundation"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]RSAT-DNS-SERVER"
            }
            WindowsFeature Web-Static-Content
            {
                Name = "Web-Static-Content"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Windows-Identity-Foundation"
            }
            WindowsFeature Web-Default-Doc
            {
                Name = "Web-Default-Doc"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Static-Content"
            }
            WindowsFeature Web-Http-Errors
            {
                Name = "Web-Http-Errors"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Default-Doc"
            }
            WindowsFeature Web-Asp-Net
            {
                Name = "Web-Asp-Net"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Errors"
            }
            WindowsFeature Web-Net-Ext
            {
                Name = "Web-Net-Ext"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Asp-Net"
            }
            WindowsFeature Web-ISAPI-Ext
            {
                Name = "Web-ISAPI-Ext"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Net-Ext"
            }
            WindowsFeature Web-ISAPI-Filter
            {
                Name = "Web-ISAPI-Filter"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-ISAPI-Ext"
            }
            WindowsFeature Web-Http-Logging
            {
                Name = "Web-Http-Logging"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-ISAPI-Filter"
            }
            WindowsFeature Web-Log-Libraries
            {
                Name = "Web-Log-Libraries"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Logging"
            }
            WindowsFeature Web-Request-Monitor
            {
                Name = "Web-Request-Monitor"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Log-Libraries"
            }
            WindowsFeature Web-Http-Tracing
            {
                Name = "Web-Http-Tracing"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Request-Monitor"
            }
            WindowsFeature Web-Basic-Auth
            {
                Name = "Web-Basic-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Tracing"
            }
            WindowsFeature Web-Windows-Auth
            {
                Name = "Web-Windows-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Basic-Auth"
            }
            WindowsFeature Web-Client-Auth
            {
                Name = "Web-Client-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Windows-Auth"
            }
            WindowsFeature Web-Filtering
            {
                Name = "Web-Filtering"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Client-Auth"
            }
            WindowsFeature Web-Stat-Compression
            {
                Name = "Web-Stat-Compression"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Filtering"
            }
            WindowsFeature Web-Dyn-Compression
            {
                Name = "Web-Dyn-Compression"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Stat-Compression"
            }
            WindowsFeature NET-WCF-HTTP-Activation45
            {
                Name = "NET-WCF-HTTP-Activation45"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Dyn-Compression"
            }
            WindowsFeature Web-Asp-Net45
            {
                Name = "Web-Asp-Net45"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]NET-WCF-HTTP-Activation45"
            }
            WindowsFeature Web-Mgmt-Tools
            {
                Name = "Web-Mgmt-Tools"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Asp-Net45"
            }
            WindowsFeature Web-Scripting-Tools
            {
                Name = "Web-Scripting-Tools"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Mgmt-Tools"
            }
            WindowsFeature Server-Media-Foundation
            {
                Name = "Server-Media-Foundation"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Scripting-Tools"
            }
            xWaitForADDomain DscForestWait 
            { 
                DomainName = $DomainName 
                DomainUserCredential= $DomainCreds
                RetryCount = $RetryCount 
                RetryIntervalSec = $RetryIntervalSec 
                DependsOn = "[WindowsFeature]Server-Media-Foundation"      
            }
            xComputer DomainJoin
            {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait" 
            }

	        Install-App -DomainName $DomainName

            LocalConfigurationManager 
            {
              ActionAfterReboot = 'StopConfiguration'
            }
        }  
}

function Install-App
{ 
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )
    
    # Script to deploy Skype for Business Server

    Write-Verbose 'STARTED:Setting up Skype for Business Server'
   
	#region Variables

	[string] $LogPath = "$TargetFolder\logs\$env:ComputerName" + " {0:yyyy-MM-dd hh-mmtt}.log" -f (Get-Date)
	[string] $LogDivider = "------------------------------"
	[string] $VCPlusPlus = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\12.0\RuntimeMinimum" -Name Version -ErrorAction SilentlyContinue).version
	[string] $SQLSysClrTypes = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{8C06D6DB-A391-4686-B050-99CC522A7843}" -Name DisplayVersion -ErrorAction SilentlyContinue).DisplayVersion
	[string] $SFBcore = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{DE39F60A-D57F-48F5-A2BD-8BA3FE794E1F}" -Name DisplayVersion -ErrorAction SilentlyContinue).DisplayVersion

	[string] $TargetFolder = "$env:SystemDrive\_Install"

	#endregion Variables
	#region DownloadURLsInstalledGUIDs
	[string] $GUIDvcplusplus2012 = "{A2CB1ACB-94A2-32BA-A15E-7D80319F7589}"

	[string] $URLdotnet = "http://download.microsoft.com/download/E/2/1/E21644B5-2DF2-47C2-91BD-63C560427900/NDP452-KB2901907-x86-x64-AllOS-ENU.exe"

	# Office Web Apps Server
	[string] $URLwacimage = "http://download.microsoft.com/download/7/7/F/77F250DC-F7A3-47AF-8B20-DDA8EE110AB4/wacserver.img"
		if ($OWASOveride){[string] $URLwacimage = "http://ehloworld.com/downloads/1697/wacserver.img"}
	[string] $URLwacenglishlanguagepack = "http://download.microsoft.com/download/5/2/B/52B01E04-313A-4F40-A858-16CE36BBDF98/wacserverlanguagepack.exe"
	# January 2015 Cumulative Update
	[string] $URLwacCU = "http://download.microsoft.com/download/C/A/0/CA0DD4D4-B593-477F-A3A7-241CF5E57856/wacserver2013-kb2956101-fullfile-x64-glb.exe"

	[string] $URLresourcekit = "http://download.microsoft.com/download/C/6/0/C60A878E-22AD-4C88-A4A1-F01BD71BA8BA/OCSReskit.msi"
	[string] $GUID2013resourcekit = "{72C84263-9F4D-4475-937E-1AEA029FE256}"

	[string] $URLpchatresourcekit = "http://download.microsoft.com/download/8/1/1/81154753-E849-46C9-A4D3-47E11838109C/PersistentChatResKit.msi"
	[string] $GUID2013pchatresourcekit = "{BBC8C4B9-D90B-4277-A9F9-3A7A2421548C}"

	[string] $URLdebuggingtools = "http://download.microsoft.com/download/C/4/6/C465D12C-60A2-47EC-B1AD-02046941B653/LyncDebugTools.msi"
	[string] $GUID2013debuggingtools = "{5043B30E-AD39-4251-8807-A2B8184E48B7}"

	[string] $URLstressandperformancetool = "http://download.microsoft.com/download/B/7/F/B7FD1DAB-F00A-4FD6-BA49-2A599B242A63/CapacityPlanningTool.msi"
	[string] $GUID2013stressperformancetool = "{94FD6E73-38F6-4DBE-AA3B-E403678868C9}"

	[string] $URLbpa = "http://download.microsoft.com/download/2/E/4/2E4CF74C-B323-4912-9ADD-C684E6346A6F/rtcbpa.msi"
	[string] $GUID2013bpa = "{597568A4-CECE-4179-99DA-C8D27382C2DB}"

	# Connectivity Analyzer 8308.582
	[string] $URLconnectivityanalyzer = "http://download.microsoft.com/download/2/1/4/2147079A-BB0C-43AA-A079-0F781F77D548/LyncConnectivityAnalyzer.msi"
	[string] $GUID2013connectivityanalyzer = "{B942730E-C0EF-48E7-8E93-CA05ADFFD026}"

	[string] $URLchm = "http://download.microsoft.com/download/F/5/9/F59AECFE-007B-4B16-A2E2-47AD2252EC54/LyncServer2013_ITPro.exe"
	[string] $URLportqry = "http://download.microsoft.com/download/3/f/4/3f4c6a54-65f0-4164-bdec-a3411ba24d3a/PortQryUI.exe"
	[string] $URLportqryconfig = "http://www.ehloworld.com/downloads/1697/Lync Portquery config.zip"
	[string] $URLucmaruntime = "http://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe"
	# [string] $URLskypeprovisioningguide = "http://download.microsoft.com/download/E/2/0/E2000C36-9C00-481A-9D96-EE43FF5C5785/Provisioning%20Guide%20for%20Lync%20-%20Skype%20Connectivity.doc"
	[string] $URLaspnetmvc4 = "http://download.microsoft.com/download/2/F/6/2F63CCD8-9288-4CC8-B58C-81D109F8F5A3/AspNetMVC4Setup.exe"
	[string] $URLlrsadminportal = "http://download.microsoft.com/download/8/7/8/878DA290-F608-4297-B1C7-4A5FC8245EA3/LyncRoomAdminPortal.exe"
	[string] $URLlatestcu = "http://download.microsoft.com/download/B/E/4/BE44AC91-C665-4522-BA93-CE72B0934DAF/LyncServerUpdateInstaller.exe"
	[string] $URLLyncOnlinePowerShellModule = "http://download.microsoft.com/download/2/0/5/2050B39B-4DA5-48E0-B768-583533B42C3B/LyncOnlinePowerShell.exe"

	# Message Analyzer 1.2 (build 4.0.7285.0)
	[string] $URLmessageanalyzer = "http://download.microsoft.com/download/2/8/3/283DE38A-5164-49DB-9883-9D1CC432174D/MessageAnalyzer64.msi"
	# Message Analyzer 1.2 Known Issues.docx
	[string] $URLmessageanalyzerknownissuesdoc = "http://download.microsoft.com/download/2/8/3/283DE38A-5164-49DB-9883-9D1CC432174D/Message%20Analyzer%201.2%20Known%20Issues.docx"
	# Message Analyzer 1.2 Operating Guide.docx
	[string] $URLmessageanalyzeroperatingguidedoc = "http://download.microsoft.com/download/2/8/3/283DE38A-5164-49DB-9883-9D1CC432174D/Microsoft%20Message%20Analyzer%20v1.2%20Operating%20Guide.docx"
	[string] $GUIDMessageAnalyzer = "{430D765D-3A30-4803-B69A-4D6E9B705834}"

	# WireShark version 1.12.4
	[string] $URLwireshark = "http://wiresharkdownloads.riverbed.com/wireshark/win64/all-versions/Wireshark-win64-1.12.4.exe"
	[string] $URLwiresharkInstall = "http://ehloworld.com/downloads/1697/WireShark_1.12.4-install.exe"
	[string] $URLwiresharkConfig = "http://ehloworld.com/downloads/1697/WireShark_1.12.4-config.exe"
	[string] $URLwiresharkplugin = "http://www.ehloworld.com/downloads/1697/LyncPacketDissector1.00.lua"

	# SCOM 8308.871
	[string] $URLwatchernode = "http://download.microsoft.com/download/9/A/0/9A06CE65-26AC-47EB-AC78-25A433CE7515/WatcherNode.msi"
	[string] $URLscommgmtpack = "http://download.microsoft.com/download/9/A/0/9A06CE65-26AC-47EB-AC78-25A433CE7515/LS2013ManagementPacks.msi"
	[string] $URLscommgmtpackdoc = "http://download.microsoft.com/download/9/A/0/9A06CE65-26AC-47EB-AC78-25A433CE7515/Lync Server 2013 Management Pack Guide.doc"

	# RASK
	[string] $URLraskusereducation = "http://download.microsoft.com/download/3/7/1/3717BF87-D7BD-4381-A22C-7908A3CF2270/RASK_Training_Resources.zip"
	[string] $URLraskcoreplanning = "http://download.microsoft.com/download/5/9/4/59410DF8-0FFA-40C9-ADBD-1E27959DFD8E/RASK_Core_Planning_Resources.zip"
	[string] $URLraskresources = "http://download.microsoft.com/download/6/1/3/613C8FEF-B681-4972-887F-0215E9D0354D/RASK_Resources.zip"

	# SDN version 2.11
	[string] $URLsdnchm = "http://download.microsoft.com/download/5/2/A/52A3F153-B152-4A8A-B710-92C5A7B11E5F/LyncSDNInterface211.chm"
	[string] $URLsdnreleasenotes = "http://download.microsoft.com/download/5/2/A/52A3F153-B152-4A8A-B710-92C5A7B11E5F/Lync%20SDN%20Interface%202%201%201%20-%20Release%20Notes.docx"
	[string] $URLsdnmgr = "http://download.microsoft.com/download/5/2/A/52A3F153-B152-4A8A-B710-92C5A7B11E5F/LyncSDNManager.msi"
	[string] $URLsdnlistener = "http://download.microsoft.com/download/5/2/A/52A3F153-B152-4A8A-B710-92C5A7B11E5F/LyncDialogListener.msi"
	[string] $URLsdnschema = "http://download.microsoft.com/download/5/2/A/52A3F153-B152-4A8A-B710-92C5A7B11E5F/LyncSDNInterface.Schema.C.xsd"

	# PowerShell 4
	[string] $URLpowershell4releasenotes = "http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows%20Management%20Framework%204.0%20Release%20Notes.docx"
	[string] $URLpowershell4dscquickpdf = "http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows%20PowerShell%20Desired%20State%20Configuration%20Quick%20Reference%20for%20Windows%20Management%20Framework%204.0.pdf"
	[string] $URLpowershell4dscquickpptx = "http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows%20PowerShell%20Desired%20State%20Configuration%20Quick%20Reference%20for%20Windows%20Management%20Framework%204.0.pptx"
	[string] $OLDURLpowershell4 = "http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows6.1-KB2819745-x64-MultiPkg.msu"
	[string] $URLpowershell4 = "http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows8-RT-KB2799888-x64.msu"

	# Silverlight version 5.1.30514.00
	[string] $URLsilverlight = "http://silverlight.dlservice.microsoft.com/download/F/8/C/F8C0EACB-92D0-4722-9B18-965DD2A681E9/30514.00/Silverlight_x64.exe"

	# Microsoft� SQL Server� 2012 Management Studio Express SP2 11.0.5058.0 (950.2MB)
	[string] $URLsqlmgmtstudio = "http://download.microsoft.com/download/0/1/E/01E0D693-2B4F-4442-9713-27A796B327BD/SQLManagementStudio_x64_ENU.exe"
	[string] $GUIDsqlserver2012mgmtstudioexpress = "{26BFF1F1-5C03-4C55-9C7C-FD65889AFA70}"

	# Microsoft� SQL Server� 2012 Management Studio Express SP1 11.0.3000.0 (921MB)
	# [string] $URLsqlmgmtstudio = "http://download.microsoft.com/download/5/2/9/529FEF7B-2EFB-439E-A2D1-A1533227CD69/SQLManagementStudio_x64_ENU.exe"

	# Microsoft� SQL Server� 2012 Management Studio Express RTM 11.0.2100.60 (600MB)
	# [string] $URLsqlmgmtstudio = "http://download.microsoft.com/download/8/D/D/8DD7BDBA-CEF7-4D8E-8C16-D9F69527F909/ENU/x64/SQLManagementStudio_x64_ENU.exe"

	# Microsoft� SQL Server� 2012 Express SP2 11.0.5058.0 (296MB)
	[string] $URLsqlexpress = "http://download.microsoft.com/download/0/1/E/01E0D693-2B4F-4442-9713-27A796B327BD/SQLEXPR_x64_ENU.exe"

	[string] $URLsqlnativeclient = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/sqlncli.msi"

	# Microsoft Online Services Sign-In Assistant (x64)
	[string] $URLLyncOnlineSignInAsst = "http://download.microsoft.com/download/7/1/E/71EF1D05-A42C-4A1F-8162-96494B5E615C/msoidcli_64bit.msi"

	# Web platform installer (for ARR 3.0)
	[string] $URLWebPlatformInstaller = "http://download.microsoft.com/download/F/4/2/F42AB12D-C935-4E65-9D98-4E56F9ACBC8E/wpilauncher.exe"

	# Digicert certificate utility
	[string] $URLDigicertUtil = "https://www.digicert.com/util/DigiCertUtil.zip"

	# Event Zero connector
	[string] $URLEventZeroConnector = "https://update.eventzero.net/EnterpriseCommander/GA/latest/CommanderConnectorsInstaller.msi"
	#endregion DownloadURLsInstalledGUIDs

	Write-Verbose 'STARTED:Setting up Skype for Business Server'
	# Net use z: \\sfbfiles.file.core.windows.net\sfbshare\

	Set-PowerPlan "High Performance"
	Install-SilverLight

    Write-Verbose 'DONE:Setting up Skype for Business Server'
}

# Setup basics

function New-FileDownload {
	<#
	.SYNOPSIS
		Downloads a file from a specified URL.

	.DESCRIPTION
		Downloads a file from a specified URL. First, it verifies the file does not exist locally. Then ensures Internet access is available, then downloads the file.

	.NOTES
	  Version							: 1.3
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param(
		# Complete path and file name to the file to be downloaded
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateNotNullOrEmpty()]
		[string] $SourceFile,

		# The folder where the downloaded file should be placed. If not defined, it defaults to $TargetFolder.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $DestFolder,

		# The file name the downloaded file should be changed to. If not defined, file maintains it's original name.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $DestFile,

		# Whether to download even if a local copy exists. This is useful for files that are updated often and need to be redownloaded.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $IgnoreLocalCopy
	)
	[bool] $HasInternetAccess = ([Activator]::CreateInstance([Type]::GetTypeFromCLSID([Guid]'{DCB00C01-570F-4A9B-8D69-199FDBA5723B}')).IsConnectedToInternet)
	Test-IsProxyEnabled
	# I should switch this to using a param block and pipelining from property name - just for consistency

	if (-not($DestFolder)){
		$DestFolder = $TargetFolder
	}
	Set-ModuleStatus -name BitsTransfer
	if (-not($DestFile)){
		[string] $DestFile = ($SourceFile | Split-Path -leaf)
		[Reflection.Assembly]::LoadWithPartialName("System.Web") | Out-Null
		$DestFile = [System.Web.HttpUtility]::UrlDecode($DestFile)
	}

	if (Test-Path $DestFolder){
		Write-Log -Message "Target folder `"$DestFolder`" exists - no need to create" -NoConsole -Indent 1
	} else {
		Write-Log -Message "Folder `"$DestFolder`" does not exist, creating..." -NoConsole
		New-Item $DestFolder -type Directory | Out-Null
		Write-Log -Message "Done!" -NoConsole -Indent 1
	}
	if ((Test-Path "$DestFolder\$DestFile") -and (-not $IgnoreLocalCopy)){
		if ($(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion)){
			Write-Log -Message "File `"$DestFile`" version $(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion) exists locally - no need to download" -NoConsole
		}else{
			Write-Log -Message "File `"$DestFile`" exists locally - no need to download" -NoConsole
		}
	} else {
		if ($HasInternetAccess){
			Write-Log -Message "Internet access available" -NoConsole -Indent 1
			if (-not $IgnoreLocalCopy){
				Write-Log -Message "File `"$DestFile`" does not exist in `"$DestFolder`"" -NoConsole -Indent 1
			} else {
				Write-Log -Message "Forcing download of `"$DestFile`" to `"$DestFolder`"" -NoConsole
			}
			Write-Log -Message "Downloading `"$SourceFile`" to `"$DestFolder`"" -NoConsole -Indent 1
			########################################################################################################
			# NOTE: Default parameters may have been changed due to proxy settings. See Test-IsProxyEnabled function
			########################################################################################################
			# determine file size before downloading
			<#
			$clnt = New-Object System.Net.WebClient
			$clnt.OpenRead($SourceFile) | Out-Null
			$dlfilesize = [int] $($clnt.ResponseHeaders["Content-Length"]/1mb)
			# $dlfilesize
			$clnt.Dispose()
			#>
			if ($dlfilesize){
				Start-BitsTransfer -Source "$SourceFile" -Destination "$DestFolder\$DestFile" -Description "Downloading $DestFile ($dlfilesize MB)" -ErrorAction SilentlyContinue
			}else{
				Start-BitsTransfer -Source "$SourceFile" -Destination "$DestFolder\$DestFile" -Description "Downloading $DestFile" -ErrorAction SilentlyContinue
			}

			if (Test-Path $DestFolder\$DestFile){
				if ($(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion)){
					Write-Log -Message "Successfully downloaded $DestFolder\$DestFile version $(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion)" -NoConsole -Indent 1
				}else{
					Write-Log -Message "Successfully downloaded $DestFolder\$DestFile" -NoConsole -Indent 1
				}
			} else {
				Write-Log -ErLevel error -message "Failed! File not downloaded!" -Indent 1
				Write-Log -Message "Prompting user to abort/retry/ignore" -NoConsole
				switch (New-Popup -message "A file download failure has occurred. What would you like to do?" -Title "Download error!" -Buttons "AbortRetryIgnore" -Icon Exclamation){
			    3{ # abort
			    	Write-Log -Message "User has chosen to abort script" -NoConsole -Indent 1
						Stop-Script
						exit
					}
			    4{ # retry
			    	Write-Log -Message "User has chosen to retry" -NoConsole -Indent 1
			    	Write-Log -Message "Building retry expression" -NoConsole -Indent 2
			    	if ($IgnoreLocalCopy){
			    		$DownloadRetry += " -IgnoreLocalCopy"
			    	}
			    	if ($DestFile){
			    		$DownloadRetry += " -DestFile $Destfile"
			    	}
			    	if ($DestFolder){
			    		$DownloadRetry += " -DestFolder $DestFolder"
			    	}
			    	$DownloadRetryExp = "New-FileDownload -SourceFile $SourceFile"+ $DownloadRetry
			    	Write-Log -Message "Retry expression is $DownloadRetryExp" -NoConsole -Indent 2
			    	Invoke-Expression $DownloadRetryExp
			    }
			    5{ # ignore
			    	Write-Log -Message "User has chosen to ignore" -NoConsole -Indent 1
			    }
				}
			}
		} else {
			#Write-Log -ErLevel warn -Message "Internet access not detected."
			#Write-Log -ErLevel warn -Message "This can be because there is no Internet connection,"
			#Write-Log -ErLevel warn -Message "there is no DNS resolution,"
			#Write-Log -ErLevel warn -Message "or a proxy is in place. Please resolve and try again."
			#Write-Log -ErLevel warn -Message "Alternatively, you can manually download the file ($SourceFile)"
			#Write-Log -ErLevel warn -Message "and place it in $DestFolder and try again."
		}
	}
} # end function New-FileDownload
function New-ProgramInstallation	{
	<#
	.SYNOPSIS
		Runs silent installation of programs, including install switches.

	.DESCRIPTION
		Runs silent installation of programs, including install switches. Script can wait for processes and/or registry values to exist before continuing.

	.NOTES
	  Version							: 1.2
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  New-ProgramInstallation -InstallFile "c:\installer.msi" -InstallSwitches "/qb"

	  Description
		-----------
		Runs installer.msi with the /qb switches

	.EXAMPLE
	  New-ProgramInstallation -InstallFile "c:\installer.msi" -InstallSwitches "/qb" -WaitForProcessName "MyProgramInstaller"

	  Description
		-----------
		Runs installer.msi with the /qb switches, and waits for the process called MyProgramInstaller to stop before continuing

	.EXAMPLE
		New-ProgramInstallation -InstallFile "c:\installer.msi" -InstallSwitches "/qb" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{90150000-1151-0000-1000-0000000FF1CE}"

		Description
		-----------
		Runs installer.msi with the /qb switches, and waits for the registry entry to be written before continuing

	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param (
		# Complete path and file name of the file to be executed.
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No installation file specified")]
		[ValidateNotNullOrEmpty()]
		[string] $InstallFile,

		# Any special command line switches to be used when executing the file.
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[string] $InstallSwitches,

		# If defined, the function will wait until the named process ends
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $WaitForProcessName,

		# If defined, the function will wait until the named registry value exists
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidatePattern("^HKLM:|^HKCU:")]
		[string] $WaitForRegistryEntry,

		# If defined, the function will wait until the named path exists
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $WaitForPath,

		# If specified, will display $LongInstallMessage to notify that this installation will take some time
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $LongInstall,

		# Text that is displayed if the installation will take a while.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $LongInstallMessage = "(this may take several minutes)"
	)
	$error.clear()
	if (Test-Path $InstallFile){
		Write-Log -Message "File exists" -NoConsole -Indent 1
		# $DestFile = $InstallFile.Substring($InstallFile.LastIndexOf("\") + 1)
		$DestFile = $($InstallFile | Split-Path -leaf)
		if (-not $LongInstall){
			Write-Log -Message "Installing `"$DestFile`""
		}else{
			Write-Log -Message "Installing `"$DestFile`" $LongInstallMessage"
		}
		$Install = $InstallFile+" "+$InstallSwitches
		Write-Log -Message "Installation command line: `"$install`"" -NoConsole -Indent 1

    # Invoke-Command might work here if we don't need to evaluate an expression

    Invoke-Expression $Install
    # Start-Process -FilePath $InstallFile -ArgumentList $InstallSwitches -Wait

		if ($WaitForPath){
			Write-Log -Message "Waiting for path `"$WaitForPath`" to exist" -NoConsole -Indent 1
			do {Start-Sleep -Seconds 1} while (-not(Test-Path "$WaitForPath"))
			Write-Log -Message "Path `"$WaitForPath`" exists" -NoConsole -Indent 1
		}

		if ($WaitForRegistryEntry){
			Write-Log -Message "Waiting for registry entry `"$WaitForRegistryEntry`" to be written" -NoConsole -Indent 1
			do {Start-Sleep -Seconds 1} while (-not(Test-Path "$WaitForRegistryEntry"))
			Write-Log -Message "Registry entry `"$WaitForRegistryEntry`" has been written" -NoConsole -Indent 1
		}

		if ($WaitForProcessName){
			Start-Sleep -s 1
			Write-Log -Message "Waiting for process `"$WaitForProcessName`" to finish running" -NoConsole -Indent 1
			Wait-Process -Name $WaitForProcessName
			# do {Start-Sleep -Seconds 1} while (Get-Process -ProcessName "$WaitForProcessName" -ErrorAction SilentlyContinue)
			Write-Log -Message "`"$WaitForProcessName`" is no longer running" -NoConsole -Indent 1
		}

		if ($error){
			Write-Log -ErLevel Error -Message "Failed!" -Indent 1
			Write-Log -ErLevel error -Message $error
		} else {
			Write-Log -Message "Installed" -Indent 1
		}
	} else {
		Write-Log -ErLevel error -message "$DestFile does not exist. Unable to proceed." -Indent 1
	}
} # end function New-ProgramInstallation
function Write-Log {
	<#
	.SYNOPSIS
		Extensive function to write data to either the console screen, a log file, and/or a Windows event log.

	.DESCRIPTION
		Extensive function to write data to either the console screen, a log file, and/or a Windows event log. Data can be written as info, warning, error, and includes indentation, time stamps, etc.

	.NOTES
	  Version							: 2.7
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		:
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		: Test for log names and sources
													http://powershell.com/cs/blogs/tips/archive/2013/06/10/testing-event-log-names-and-sources.aspx
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param(
		# The type of message to be logged. Alias is 'type'.
		[Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[ValidateSet("Error", "Warn", "Info")]
		[ValidateNotNullOrEmpty()]
		[string] $ErLevel = "Info",

		# The message to be logged.
		[Parameter(Position = 1, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No message specified.")]
		[ValidateNotNullOrEmpty()]
		[string] $Message,

		# Specifies that $message should not the sent to the log file.
		[Parameter(Position = 2, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $NoLog,

		# Specifies to not display the message to the console.
		[Parameter(Position = 3, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $NoConsole,

		# The number of spaces to indent the message in the log file.
		[Parameter(Position = 4, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateRange(1,30)]
		[ValidateNotNullOrEmpty()]
		[Int16] $Indent = 0,

		# Specifies what color the text should be be displayed on the console. Ignored when switch 'NoConsoleOut' is specified.
		[Parameter(Position = 5, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateSet("Black", "DarkMagenta", "DarkRed", "DarkBlue", "DarkGreen", "DarkCyan", "DarkYellow", "Red", "Blue", "Green", "Cyan", "Magenta", "Yellow", "DarkGray", "Gray", "White")]
		[ValidateNotNullOrEmpty()]
		[String] $ConsoleForeground = 'White',

		# Existing log file is deleted when this is specified. Alias is 'Overwrite'.
		[Parameter(Position = 6, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[Switch] $Clobber,

		# The name of the system event log, e.g. 'Application'. Note that writing to the system event log requires elevated permissions.
		[Parameter(Position = 7, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateSet("Application","System","Security","Lync Server","Microsoft Office Web Apps")]
		[ValidateNotNullOrEmpty()]
		[String] $EventLogName = "Application",

		# The name to appear as the source attribute for the system event log entry. This is ignored unless 'EventLogName' is specified.
		[Parameter(Position = 8, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateNotNullOrEmpty()]
		[String] $EventSource = $($MyInvocation.ScriptName).Name,

		# The ID to appear as the event ID attribute for the system event log entry. This is ignored unless 'EventLogName' is specified.
		[Parameter(Position = 9, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateRange(1,65535)]
		[ValidateNotNullOrEmpty()]
		[Int32] $EventID = 1,

		# The text encoding for the log file. Default is ASCII.
		[Parameter(Position = 10, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateSet("Unicode","Byte","BigEndianUnicode","UTF8","UTF7","UTF32","ASCII","Default","OEM")]
		[ValidateNotNullOrEmpty()]
		[String] $LogEncoding = "ASCII"
	)
	try {
		[string]$LogFolder = Split-Path $LogPath -Parent
		if (-not(Test-Path $LogFolder)){New-Item $LogFolder -type Directory | Out-Null}
		$msg = "{0} : {1} : {2}{3}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $ErLevel.ToUpper(), ("  " * $Indent), $Message
		if (-not($NoConsole)){
			switch ($ErLevel) {
				"Error" {$Host.UI.WriteErrorLine("$Message")}
				"Warn" {Write-Warning $Message}
				"Info" {Write-Host $Message -ForegroundColor $ConsoleForeground}
			}
		}
		if (-not($NoLog)){
			if ($Clobber) {
				$msg | Out-File -FilePath $LogPath -Encoding $LogEncoding -Force
			} else {
				$msg | Out-File -FilePath $LogPath -Encoding $LogEncoding -Append
			}
		}

		# http://social.technet.microsoft.com/Forums/en-US/winserverpowershell/thread/e172f039-ce88-4c9f-b19a-0dd6dc568fa0/

		if ($EventLogName) {
			if (-not $EventSource) {
				[string] $EventSource = $([IO.FileInfo] $MyInvocation.ScriptName).Name
			}

			if(-not [Diagnostics.EventLog]::SourceExists($EventSource)) {
				[Diagnostics.EventLog]::CreateEventSource($EventSource, $EventLogName)
	    }

			switch ($ErLevel) {
				"Error" {$EntryType = "Error"}
				"Warn"  {$EntryType = "Warning"}
				"Info"  {$EntryType = "Information"}
				Default  {$EntryType = "Information"}
			}
			Write-EventLog -LogName $EventLogName -Source $EventSource -EventId 1 -EntryType $EntryType -Message $Message
		}
		$msg = ""
	}
	catch {
		Throw "Failed to create log entry in: '$LogPath'. The error was: '$_'."
	}
} # end function Write-Log
function Test-IsProxyEnabled {
	<#
	.SYNOPSIS
		Determines (the best it can) if a proxy is in place for Internet access.

	.DESCRIPTION
		Determines (the best it can) if a proxy is in place for Internet access. If so, other functions that download files can better handle downloads.

	.NOTES
	  Version							: 1.1
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param ()
	Write-Log -Message "Checking if a proxy is enabled" -NoConsole -Indent 1
	# If this registry key doesn't exist at all, it's because IE has never been launched. We need to create it here so that download attempts and proxy checks don't throw a silent error
	if ((Get-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").Property -notcontains "ProxyEnable"){
		Write-Log -Message "Internet Explorer has never been opened. Proxy registry values have yet to be set. Setting it to 0 now." -NoConsole -Indent 1
		New-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyEnable -Value 0 | Out-Null
	}
	if ((Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -name ProxyEnable -ErrorAction SilentlyContinue).ProxyEnable -ne 0){
		Write-Log -Message "A proxy is required" -NoConsole -Indent 2
		[string]$ProxyServer = (Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -name ProxyServer).ProxyServer
		Write-Log -Message "Configured proxy: `"$ProxyServer`"" -NoConsole -Indent 2

		if (-not($PSDefaultParameterValues.ContainsKey("Start-BitsTransfer:ProxyAuthentication"))){
			Write-Log -Message "Prompting for credentials" -NoConsole -Indent 2
			$ProxyCredentials = Get-Credential -Message "Enter Proxy authentication credentials for $ProxyServer" -UserName "${env:USERDOMAIN}\${env:UserName}"
    	if ($ProxyCredentials){
    		Write-Log -Message "Credentials entered" -NoConsole -Indent 2
    		Write-Log -Message "Adding default values for Start-BitsTransfer" -NoConsole -Indent 2
    		Write-Log -Message "Adding default value for ProxyAuthentication - `"Basic`"" -NoConsole -Indent 2
    		$PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyAuthentication","Basic")
    		$ProxyUserName = $ProxyCredentials.username
    		Write-Log -Message "Adding default value for ProxyCredential - `"$ProxyUserName`"" -NoConsole -Indent 2
    		$PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyCredential",$ProxyCredentials)
    		# Write-Log -Message "Adding default value for ProxyList - `"$ProxyServer`"" -NoConsole -Indent 1
    		# $PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyList",$ProxyServer)
    		# Write-Log -Message "Adding default value for ProxyUsage - `"AutoDetect`"" -NoConsole -Indent 1
    		# $PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyUsage","AutoDetect")
			} else {
				Write-Log -ErLevel error -message "Credentials NOT entered. Following commands will likely fail" -NoConsole -Indent 2
			}
    }
	} else {
		Write-Log -Message "Proxy is not enabled" -NoConsole -Indent 2
		# Clear the error queue in case the proxy registry key didn't exist at all and threw an error.
		$error.clear()
	}
} # end function Test-IsProxyEnabled
function New-Popup {
	<#
	.Synopsis
		Display a Popup Message

	.Description
		This command uses the Wscript.Shell PopUp method to display a graphical message
		box. You can customize its appearance of icons and buttons. By default the user
		must click a button to dismiss but you can set a timeout value in seconds to
		automatically dismiss the popup.

		The command will write the return value of the clicked button to the pipeline:
		  OK     = 1
		  Cancel = 2
		  Abort  = 3
		  Retry  = 4
		  Ignore = 5
		  Yes    = 6
		  No     = 7

		If no button is clicked, the return value is -1.

	.Example
	PS C:\> new-popup -message "The update script has completed" -title "Finished" -time 5

	This will display a popup message using the default OK button and default
	Information icon. The popup will automatically dismiss after 5 seconds.

	.Notes
		Last Updated: April 8, 2013
		Version     : 1.0

	.Inputs
		None

	.Outputs
		integer

		Null   = -1
		OK     = 1
		Cancel = 2
		Abort  = 3
		Retry  = 4
		Ignore = 5
		Yes    = 6
		No     = 7
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	Param (
		# Message to be displayed in the popup message dialog box.
		[Parameter(Position = 0, Mandatory = $True, HelpMessage = "Enter a message for the popup")]
		[ValidateNotNullorEmpty()]
		[string] $Message,

		# Title of the popup dialog box.
		[Parameter(Position = 1, Mandatory = $True, HelpMessage = "Enter a title for the popup")]
		[ValidateNotNullorEmpty()]
		[string] $Title,

		# If defined, automatically dismisses the dialog box after the specified number of seconds. Defaults to 0, which requires a mouse click.
		[Parameter(Position = 2, HelpMessage = "How many seconds to display? Use 0 require a button click.")]
		[ValidateScript({$_ -ge 0})]
		[int] $Time = 0,

		# Type of buttons to display.
		[Parameter(Position = 3, HelpMessage = "Enter a button group")]
		[ValidateNotNullorEmpty()]
		[ValidateSet("OK","OKCancel","AbortRetryIgnore","YesNo","YesNoCancel","RetryCancel")]
		[string] $Buttons = "OK",

		# Icon set to use in dialog box.
		[Parameter(Position = 4, HelpMessage = "Enter an icon set")]
		[ValidateNotNullorEmpty()]
		[ValidateSet("Stop","Question","Exclamation","Information" )]
		[string] $Icon = "Information"
	)

	#convert buttons to their integer equivalents
	Switch ($Buttons) {
		"OK"               {$ButtonValue = 0}
		"OKCancel"         {$ButtonValue = 1}
		"AbortRetryIgnore" {$ButtonValue = 2}
		"YesNo"            {$ButtonValue = 4}
		"YesNoCancel"      {$ButtonValue = 3}
		"RetryCancel"      {$ButtonValue = 5}
	}

	#set an integer value for Icon type
	Switch ($Icon) {
		"Stop"        {$iconValue = 16}
		"Question"    {$iconValue = 32}
		"Exclamation" {$iconValue = 48}
		"Information" {$iconValue = 64}
	}

	#create the COM Object
	Try {
	  $wshell = New-Object -ComObject Wscript.Shell -ErrorAction Stop
	  #Button and icon type values are added together to create an integer value
	  $wshell.Popup($Message,$Time,$Title,$ButtonValue+$iconValue)
	}

	Catch {
	  #You should never really run into an exception in normal usage
	  Write-Log -ErLevel warn -message "Failed to create Wscript.Shell COM object"
	  Write-Log -ErLevel warn -message $_.exception.message
	}
} # end function New-Popup
function Set-ModuleStatus {
	<#
	.SYNOPSIS
		Imports a specified PowerShell module, with error checking.

	.DESCRIPTION
		Imports a specified PowerShell module, with error checking.

	.NOTES
	  Version							: 1.5
		Wish list						: Better error trapping
	  Rights Required			: None
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param	(
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No module name specified!")]
		[ValidateNotNullOrEmpty()]
		[string] $name
	)
	PROCESS{
		# Executes once for each pipeline object
		# the $_ variable represents the current input object
		if (-not(Get-Module -name "$name")) {
			if (Get-Module -ListAvailable | Where-Object Name -eq "$name") {
				Import-Module -Name "$name"
				# module was imported
				# return $true
			} else {
				# module was not available
				# return $false
			}
		} else {
			# Write-Output "$_ module already imported"
			# return $true
		}
	} # end PROCESS
} # end function Set-ModuleStatus
function Test-IsRebootRequired	{ # http://technet.microsoft.com/en-us/library/cc164360(v=EXCHG.80).aspx
	<#
	.SYNOPSIS
		Looks for key indicators that a restart is required on the local machine.

	.DESCRIPTION
		Looks for key indicators that a restart is required on the local machine. This is done by checking known registry keys, as well as some variables set within the script itself. It returns a true/false.

	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: None
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param()
	if ((Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue) -or (Test-Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") -or (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name rebootrequired -ErrorAction SilentlyContinue) -or $RestartRequired){
		$RestartNeeded = $true
		return $true
	}
} # end function Test-IsRebootRequired

# Main Functions

function Set-PowerPlan {
	<#
	.SYNOPSIS
		Configures the Power Plan on the local machine. Called from Set-HighPower.

	.DESCRIPTION
		Configures the Power Plan on the local machine. Called from Set-HighPower.

	.NOTES
	  Version							: 1.2
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:	http://www.ehloworld.com/2558
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK
		http://www.ehloworld.com/2558

	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param (
		# Defines the power plan the set the computer to
		[ValidateSet("High performance", "Balanced", "Power saver")]
		[ValidateNotNullOrEmpty()]
		[string] $PreferredPlan = "High Performance"
	)

	Write-Log -Message "Setting power plan to `"$PreferredPlan`"" -NoConsole -Indent 1
	$guid = (Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "ElementName='$PreferredPlan'").InstanceID.ToString()
	$regex = [regex]"{(.*?)}$"
	$plan = $regex.Match($guid).groups[1].value

	powercfg -S $plan
	$Output = "Power plan set to "
	$Output += "`"" + ((Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "IsActive='$True'").ElementName) + "`""
	Write-Log -Message $Output -NoConsole -Indent 1
} # end function Set-PowerPlan

function Set-PrimaryDNSSuffix {
	<#
	.SYNOPSIS


	.DESCRIPTION


	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:	http://www.ehloworld.com/2558
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE


	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param ()
	if ((Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name Domain).Domain -notmatch "([A-Za-z0-9-]{2,63}\.\w{2,63}\.\w{2,63}|\w{2,63}\.\w{2,63})$"){
		[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
		do {
			Write-Log -Message "Prompting for primary DNS suffix" -NoConsole -Indent 1
			$DomainSuffix = [Microsoft.VisualBasic.Interaction]::InputBox("Enter primary domain suffix", "Computer name/domain changes", "")
		}while(
			$DomainSuffix -notmatch "([A-Za-z0-9-]{2,63}\.\w{2,63}\.\w{2,63}|\w{2,63}\.\w{2,63})$"
		)
		if ($DomainSuffix){
			Write-Log -Message "User entered $DomainSuffix" -NoConsole -Indent 1
			Write-Log -Message "Adding $DomainSuffix to $env:ComputerName" -NoConsole -Indent 1
			netdom computername $env:ComputerName /add:$env:ComputerName.$DomainSuffix
			Write-Log -Message "Making $DomainSuffix the primary name" -NoConsole -Indent 1
			netdom computername $env:ComputerName /makeprimary:$env:ComputerName.$DomainSuffix | Out-Null
			$RestartRequired = $true
		}
		if ($RestartRequired){
			Write-Log -ErLevel Warn -Message "Restart is required" -NoConsole -Indent 1
			Write-Log -ErLevel Warn -Message "Prompting for restart" -NoConsole -Indent 1
			if ((New-Popup -Message "Successfully changed the primary name for the computer. The computer must be rebooted for this name change to take effect. The specified new name was removed from the list of alternate computer names. The primary computer name will be set to the specified new name after the reboot. Restart now?" -Title "Computer name/domain changes" -Buttons YesNo -Icon Question) -eq 6){
				Write-Log -Message "User chose to reboot" -NoConsole
				Stop-Script -reboot
			} else {
				Write-Log -ErLevel Warn -Message "User chose NOT to reboot" -NoConsole
				Stop-Script
			}
		}
	}else{
		Write-Log -ErLevel Warn -Message "Primary DNS suffix already configured"
	}
} # end function Set-PrimaryDNSSuffix

function Install-SilverLight {
	<#
	.SYNOPSIS
		Installs Microsoft SilverLight on the local machine.

	.DESCRIPTION
		Installs Microsoft SilverLight on the local machine.

	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param()
	Write-Log -Message "Installing Microsoft Silverlight"
	Write-Log -Message "Checking if Silverlight is already installed" -NoConsole
	if (-not(Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}")){
		Write-Log -Message "Silverlight is not installed" -NoConsole -Indent 1
		New-FileDownload $URLsilverlight
		New-ProgramInstallation -InstallFile "$TargetFolder\$($URLsilverlight | Split-Path -leaf)" -InstallSwitches "/q" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}"
		# remove pinned shortcut on desktop to "C:\Program Files\Microsoft Silverlight\5.1.10411.0\Silverlight.Configuration.exe"
	} else {
		Write-Log -Message "Silverlight already installed" -Indent 1
	}
} # end function Install-SilverLight

function Install-VisualCRedist {
	<#
	.SYNOPSIS
		Installs Microsoft Visual C Redist on the local machine.

	.DESCRIPTION
		Installs Microsoft Visual C Redist on the local machine.

	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Clive Graven - All Rights Reserved
	  Email/Blog/Twitter	: cliveg@microsoft.com 	@cliveag
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param()
	Write-Log -Message "Installing Microsoft Silverlight"
	Write-Log -Message "Checking if Silverlight is already installed" -NoConsole
	if (-not(Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}")){
		Write-Log -Message "Silverlight is not installed" -NoConsole -Indent 1
		New-FileDownload $URLsilverlight
		New-ProgramInstallation -InstallFile "$TargetFolder\$($URLsilverlight | Split-Path -leaf)" -InstallSwitches "/q" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}"
#New-ProgramInstallation -InstallFile "$TargetFolder\$($URLstressandperformancetool | Split-Path -leaf)" -InstallSwitches "/qb" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$GUID2013stressperformancetool" -WaitForProcessName "CapacityPlanningTool.msi"
		# remove pinned shortcut on desktop to "C:\Program Files\Microsoft Silverlight\5.1.10411.0\Silverlight.Configuration.exe"
	} else {
		Write-Log -Message "Silverlight already installed" -Indent 1
	}
} # end function Install-SilverLight


#endregion Functions

#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSkypeForBusinessServer
{
	
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [parameter(Mandatory)]
        [String]$DatabaseServer,
      
        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60,

		# Skype for Business Server
		[string] $URLsfbServer = "http://sfbfiles.blob.core.windows.net/software/en_skype_for_business_server_2015_x64_dvd_6622058.iso",
		[string] $ISOfile = "c:\en_skype_for_business_server_2015_x64_dvd_6622058.iso",
		[string] $LogPath = "$TargetFolder\logs\$env:ComputerName" + " {0:yyyy-MM-dd hh-mmtt}.log" -f (Get-Date),
		[string] $LogDivider = "------------------------------",
		[string] $VCPlusPlus = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\12.0\RuntimeMinimum" -Name Version -ErrorAction SilentlyContinue).version,
		[string] $SQLSysClrTypes = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{8C06D6DB-A391-4686-B050-99CC522A7843}" -Name DisplayVersion -ErrorAction SilentlyContinue).DisplayVersion,
		[string] $SFBcore = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{DE39F60A-D57F-48F5-A2BD-8BA3FE794E1F}" -Name DisplayVersion -ErrorAction SilentlyContinue).DisplayVersion,

		[string] $TargetFolder = "$env:SystemDrive\_Install",

		#endregion Variables

		# Silverlight version 5.1.30514.00
		[string] $URLsilverlight = "http://silverlight.dlservice.microsoft.com/download/F/8/C/F8C0EACB-92D0-4722-9B18-965DD2A681E9/30514.00/Silverlight_x64.exe",

		# Microsoft Online Services Sign-In Assistant (x64)
		[string] $URLLyncOnlineSignInAsst = "http://download.microsoft.com/download/7/1/E/71EF1D05-A42C-4A1F-8162-96494B5E615C/msoidcli_64bit.msi"

		#region Variables
    )

        Write-Verbose "AzureExtensionHandler loaded continuing with configuration"

        [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)


        # Install Skype For Business Module
        $ModuleFilePath="$PSScriptRoot\SkypeForBusiness.psm1"
        $ModuleName = "SharepointServer"
        $PSModulePath = $Env:PSModulePath -split ";" | Select -Index 1
        $ModuleFolder = "$PSModulePath\$ModuleName"
        #if (-not (Test-Path  $ModuleFolder -PathType Container)) {
            # mkdir $ModuleFolder
        #}
        # Copy-Item $ModuleFilePath $ModuleFolder -Force

        Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xDisk, xCredSSP, cDisk, xNetworking
    
        Node localhost
        {
            
            xWaitforDisk Disk2
            {
                DiskNumber = 2
                RetryIntervalSec =$RetryIntervalSec
                RetryCount = $RetryCount
            }
            cDiskNoRestart SPDataDisk
            {
                DiskNumber = 2
                DriveLetter = "F"
                DependsOn = "[xWaitforDisk]Disk2"
            }
            xCredSSP Server 
            { 
                Ensure = "Present" 
                Role = "Server" 
            } 
            xCredSSP Client 
            { 
                Ensure = "Present" 
                Role = "Client" 
                DelegateComputers = "*.$Domain", "localhost"
            }
            WindowsFeature ADPS
            {
                Name = "RSAT-AD-PowerShell"
                Ensure = "Present"
                DependsOn = "[cDiskNoRestart]SPDataDisk"
            }
            WindowsFeature NET-Framework-Core
            {
                Name = "NET-Framework-Core"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]ADPS"
            }
            WindowsFeature RSAT-ADDS
            {
                Name = "RSAT-ADDS"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]NET-Framework-Core"
            }
            WindowsFeature RSAT-DNS-SERVER
            {
                Name = "RSAT-DNS-SERVER"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]RSAT-ADDS"
            }
            WindowsFeature Windows-Identity-Foundation
            {
                Name = "Windows-Identity-Foundation"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]RSAT-DNS-SERVER"
            }
            WindowsFeature Web-Static-Content
            {
                Name = "Web-Static-Content"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Windows-Identity-Foundation"
            }
            WindowsFeature Web-Default-Doc
            {
                Name = "Web-Default-Doc"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Static-Content"
            }
            WindowsFeature Web-Http-Errors
            {
                Name = "Web-Http-Errors"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Default-Doc"
            }
            WindowsFeature Web-Asp-Net
            {
                Name = "Web-Asp-Net"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Errors"
            }
            WindowsFeature Web-Net-Ext
            {
                Name = "Web-Net-Ext"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Asp-Net"
            }
            WindowsFeature Web-ISAPI-Ext
            {
                Name = "Web-ISAPI-Ext"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Net-Ext"
            }
            WindowsFeature Web-ISAPI-Filter
            {
                Name = "Web-ISAPI-Filter"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-ISAPI-Ext"
            }
            WindowsFeature Web-Http-Logging
            {
                Name = "Web-Http-Logging"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-ISAPI-Filter"
            }
            WindowsFeature Web-Log-Libraries
            {
                Name = "Web-Log-Libraries"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Logging"
            }
            WindowsFeature Web-Request-Monitor
            {
                Name = "Web-Request-Monitor"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Log-Libraries"
            }
            WindowsFeature Web-Http-Tracing
            {
                Name = "Web-Http-Tracing"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Request-Monitor"
            }
            WindowsFeature Web-Basic-Auth
            {
                Name = "Web-Basic-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Http-Tracing"
            }
            WindowsFeature Web-Windows-Auth
            {
                Name = "Web-Windows-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Basic-Auth"
            }
            WindowsFeature Web-Client-Auth
            {
                Name = "Web-Client-Auth"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Windows-Auth"
            }
            WindowsFeature Web-Filtering
            {
                Name = "Web-Filtering"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Client-Auth"
            }
            WindowsFeature Web-Stat-Compression
            {
                Name = "Web-Stat-Compression"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Filtering"
            }
            WindowsFeature Web-Dyn-Compression
            {
                Name = "Web-Dyn-Compression"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Stat-Compression"
            }
            WindowsFeature NET-WCF-HTTP-Activation45
            {
                Name = "NET-WCF-HTTP-Activation45"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Dyn-Compression"
            }
            WindowsFeature Web-Asp-Net45
            {
                Name = "Web-Asp-Net45"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]NET-WCF-HTTP-Activation45"
            }
            WindowsFeature Web-Mgmt-Tools
            {
                Name = "Web-Mgmt-Tools"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Asp-Net45"
            }
            WindowsFeature Web-Scripting-Tools
            {
                Name = "Web-Scripting-Tools"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Mgmt-Tools"
            }
            WindowsFeature Server-Media-Foundation
            {
                Name = "Server-Media-Foundation"
                Ensure = "Present"
                DependsOn = "[WindowsFeature]Web-Scripting-Tools"
            }
            xWaitForADDomain DscForestWait 
            { 
                DomainName = $DomainName 
                DomainUserCredential= $DomainCreds
                RetryCount = $RetryCount 
                RetryIntervalSec = $RetryIntervalSec 
                DependsOn = "[WindowsFeature]Server-Media-Foundation"      
            }
            xComputer DomainJoin
            {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait" 
            }

	        #Install-App -DomainName $DomainName
			#Set-PowerPlan "High Performance"
			#Install-SilverLight
			#New-FileDownload $URLsfbServer
			#Extract-ISO $ISOfile "F:\sfbserver\"

            LocalConfigurationManager 
            {
              ActionAfterReboot = 'StopConfiguration'
            }
        }  
}

function Install-App
{ 
    param(
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )
    
    # Script to deploy Skype for Business Server

    Write-Verbose 'STARTED:Setting up Skype for Business Server'
   

	Write-Verbose 'STARTED:Setting up Skype for Business Server'
	# Net use z: \\sfbfiles.file.core.windows.net\sfbshare\



    Write-Verbose 'DONE:Setting up Skype for Business Server'

} # end function Install-App

# Setup basics
function Extract-ISO {
	<#
	.SYNOPSIS
		Extract ISO.

	.DESCRIPTION
		Extract ISO.

	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Clive Graven - All Rights Reserved
	  Email/Blog/Twitter	: cliveg@microsoft.com 	@cliveag
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param (
		# Complete path and file name of the file to be executed.
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No installation file specified")]
		[ValidateNotNullOrEmpty()]
		[string] $isoFile,

		# Destination folder.
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "Destination folder")]
		[ValidateNotNullOrEmpty()]
		[string] $folder
    )
	Write-Log -Message "Extracting ISO"

    $mount_params = @{ImagePath = $isoFile; PassThru = $true; ErrorAction = "Ignore"}
    $mount = Mount-DiskImage @mount_params

     if($mount) {
         $volume = Get-DiskImage -ImagePath $mount.ImagePath | Get-Volume
         $source = $volume.DriveLetter + ":\*"
        
         Write-Host "Extracting '$isofile' to '$folder'..."
         xcopy $source $folder /s /e /c
         $hide = Dismount-DiskImage @mount_params
         Write-Host "Copy complete"
    }
    else {
         Write-Host "ERROR: Could not mount " $isofile " check if file is already in use"
    }
} # end function Extract-ISO

function New-FileDownload {
	<#
	.SYNOPSIS
		Downloads a file from a specified URL.

	.DESCRIPTION
		Downloads a file from a specified URL. First, it verifies the file does not exist locally. Then ensures Internet access is available, then downloads the file.

	.NOTES
	  Version							: 1.3
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param(
		# Complete path and file name to the file to be downloaded
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateNotNullOrEmpty()]
		[string] $SourceFile,

		# The folder where the downloaded file should be placed. If not defined, it defaults to $TargetFolder.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $DestFolder,

		# The file name the downloaded file should be changed to. If not defined, file maintains it's original name.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $DestFile,

		# Whether to download even if a local copy exists. This is useful for files that are updated often and need to be redownloaded.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $IgnoreLocalCopy
	)
	[bool] $HasInternetAccess = ([Activator]::CreateInstance([Type]::GetTypeFromCLSID([Guid]'{DCB00C01-570F-4A9B-8D69-199FDBA5723B}')).IsConnectedToInternet)
	Test-IsProxyEnabled
	# I should switch this to using a param block and pipelining from property name - just for consistency

	if (-not($DestFolder)){
		$DestFolder = $TargetFolder
	}
	Set-ModuleStatus -name BitsTransfer
	if (-not($DestFile)){
		[string] $DestFile = ($SourceFile | Split-Path -leaf)
		[Reflection.Assembly]::LoadWithPartialName("System.Web") | Out-Null
		$DestFile = [System.Web.HttpUtility]::UrlDecode($DestFile)
	}

	if (Test-Path $DestFolder){
		Write-Log -Message "Target folder `"$DestFolder`" exists - no need to create" -NoConsole -Indent 1
	} else {
		Write-Log -Message "Folder `"$DestFolder`" does not exist, creating..." -NoConsole
		New-Item $DestFolder -type Directory | Out-Null
		Write-Log -Message "Done!" -NoConsole -Indent 1
	}
	if ((Test-Path "$DestFolder\$DestFile") -and (-not $IgnoreLocalCopy)){
		if ($(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion)){
			Write-Log -Message "File `"$DestFile`" version $(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion) exists locally - no need to download" -NoConsole
		}else{
			Write-Log -Message "File `"$DestFile`" exists locally - no need to download" -NoConsole
		}
	} else {
		if ($HasInternetAccess){
			Write-Log -Message "Internet access available" -NoConsole -Indent 1
			if (-not $IgnoreLocalCopy){
				Write-Log -Message "File `"$DestFile`" does not exist in `"$DestFolder`"" -NoConsole -Indent 1
			} else {
				Write-Log -Message "Forcing download of `"$DestFile`" to `"$DestFolder`"" -NoConsole
			}
			Write-Log -Message "Downloading `"$SourceFile`" to `"$DestFolder`"" -NoConsole -Indent 1
			########################################################################################################
			# NOTE: Default parameters may have been changed due to proxy settings. See Test-IsProxyEnabled function
			########################################################################################################
			# determine file size before downloading
			<#
			$clnt = New-Object System.Net.WebClient
			$clnt.OpenRead($SourceFile) | Out-Null
			$dlfilesize = [int] $($clnt.ResponseHeaders["Content-Length"]/1mb)
			# $dlfilesize
			$clnt.Dispose()
			#>
			if ($dlfilesize){
				Start-BitsTransfer -Source "$SourceFile" -Destination "$DestFolder\$DestFile" -Description "Downloading $DestFile ($dlfilesize MB)" -ErrorAction SilentlyContinue
			}else{
				Start-BitsTransfer -Source "$SourceFile" -Destination "$DestFolder\$DestFile" -Description "Downloading $DestFile" -ErrorAction SilentlyContinue
			}

			if (Test-Path $DestFolder\$DestFile){
				if ($(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion)){
					Write-Log -Message "Successfully downloaded $DestFolder\$DestFile version $(((Get-Item $DestFolder\$DestFile).VersionInfo).FileVersion)" -NoConsole -Indent 1
				}else{
					Write-Log -Message "Successfully downloaded $DestFolder\$DestFile" -NoConsole -Indent 1
				}
			} else {
				Write-Log -ErLevel Error -message "Failed! File not downloaded!" -Indent 1
				Write-Log -Message "Prompting user to abort/retry/ignore" -NoConsole
				switch (New-Popup -message "A file download failure has occurred. What would you like to do?" -Title "Download error!" -Buttons "AbortRetryIgnore" -Icon Exclamation){
			    3{ # abort
			    	Write-Log -Message "User has chosen to abort script" -NoConsole -Indent 1
						Stop-Script
						exit
					}
			    4{ # retry
			    	Write-Log -Message "User has chosen to retry" -NoConsole -Indent 1
			    	Write-Log -Message "Building retry expression" -NoConsole -Indent 2
			    	if ($IgnoreLocalCopy){
			    		$DownloadRetry += " -IgnoreLocalCopy"
			    	}
			    	if ($DestFile){
			    		$DownloadRetry += " -DestFile $Destfile"
			    	}
			    	if ($DestFolder){
			    		$DownloadRetry += " -DestFolder $DestFolder"
			    	}
			    	$DownloadRetryExp = "New-FileDownload -SourceFile $SourceFile"+ $DownloadRetry
			    	Write-Log -Message "Retry expression is $DownloadRetryExp" -NoConsole -Indent 2
			    	Invoke-Expression $DownloadRetryExp
			    }
			    5{ # ignore
			    	Write-Log -Message "User has chosen to ignore" -NoConsole -Indent 1
			    }
				}
			}
		} else {
			#Write-Log -ErLevel Warn -Message "Internet access not detected."
			#Write-Log -ErLevel Warn -Message "This can be because there is no Internet connection,"
			#Write-Log -ErLevel Warn -Message "there is no DNS resolution,"
			#Write-Log -ErLevel Warn -Message "or a proxy is in place. Please resolve and try again."
			#Write-Log -ErLevel Warn -Message "Alternatively, you can manually download the file ($SourceFile)"
			#Write-Log -ErLevel Warn -Message "and place it in $DestFolder and try again."
		}
	}
} # end function New-FileDownload
function New-ProgramInstallation	{
	<#
	.SYNOPSIS
		Runs silent installation of programs, including install switches.

	.DESCRIPTION
		Runs silent installation of programs, including install switches. Script can wait for processes and/or registry values to exist before continuing.

	.NOTES
	  Version							: 1.2
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  New-ProgramInstallation -InstallFile "c:\installer.msi" -InstallSwitches "/qb"

	  Description
		-----------
		Runs installer.msi with the /qb switches

	.EXAMPLE
	  New-ProgramInstallation -InstallFile "c:\installer.msi" -InstallSwitches "/qb" -WaitForProcessName "MyProgramInstaller"

	  Description
		-----------
		Runs installer.msi with the /qb switches, and waits for the process called MyProgramInstaller to stop before continuing

	.EXAMPLE
		New-ProgramInstallation -InstallFile "c:\installer.msi" -InstallSwitches "/qb" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{90150000-1151-0000-1000-0000000FF1CE}"

		Description
		-----------
		Runs installer.msi with the /qb switches, and waits for the registry entry to be written before continuing

	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param (
		# Complete path and file name of the file to be executed.
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No installation file specified")]
		[ValidateNotNullOrEmpty()]
		[string] $InstallFile,

		# Any special command line switches to be used when executing the file.
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[string] $InstallSwitches,

		# If defined, the function will wait until the named process ends
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $WaitForProcessName,

		# If defined, the function will wait until the named registry value exists
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidatePattern("^HKLM:|^HKCU:")]
		[string] $WaitForRegistryEntry,

		# If defined, the function will wait until the named path exists
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $WaitForPath,

		# If specified, will display $LongInstallMessage to notify that this installation will take some time
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $LongInstall,

		# Text that is displayed if the installation will take a while.
		[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[string] $LongInstallMessage = "(this may take several minutes)"
	)
	$error.clear()
	if (Test-Path $InstallFile){
		Write-Log -Message "File exists" -NoConsole -Indent 1
		# $DestFile = $InstallFile.Substring($InstallFile.LastIndexOf("\") + 1)
		$DestFile = $($InstallFile | Split-Path -leaf)
		if (-not $LongInstall){
			Write-Log -Message "Installing `"$DestFile`""
		}else{
			Write-Log -Message "Installing `"$DestFile`" $LongInstallMessage"
		}
		$Install = $InstallFile+" "+$InstallSwitches
		Write-Log -Message "Installation command line: `"$install`"" -NoConsole -Indent 1

    # Invoke-Command might work here if we don't need to evaluate an expression

    Invoke-Expression $Install
    # Start-Process -FilePath $InstallFile -ArgumentList $InstallSwitches -Wait

		if ($WaitForPath){
			Write-Log -Message "Waiting for path `"$WaitForPath`" to exist" -NoConsole -Indent 1
			do {Start-Sleep -Seconds 1} while (-not(Test-Path "$WaitForPath"))
			Write-Log -Message "Path `"$WaitForPath`" exists" -NoConsole -Indent 1
		}

		if ($WaitForRegistryEntry){
			Write-Log -Message "Waiting for registry entry `"$WaitForRegistryEntry`" to be written" -NoConsole -Indent 1
			do {Start-Sleep -Seconds 1} while (-not(Test-Path "$WaitForRegistryEntry"))
			Write-Log -Message "Registry entry `"$WaitForRegistryEntry`" has been written" -NoConsole -Indent 1
		}

		if ($WaitForProcessName){
			Start-Sleep -s 1
			Write-Log -Message "Waiting for process `"$WaitForProcessName`" to finish running" -NoConsole -Indent 1
			Wait-Process -Name $WaitForProcessName
			# do {Start-Sleep -Seconds 1} while (Get-Process -ProcessName "$WaitForProcessName" -ErrorAction SilentlyContinue)
			Write-Log -Message "`"$WaitForProcessName`" is no longer running" -NoConsole -Indent 1
		}

		if ($error){
			Write-Log -ErLevel Error -Message "Failed!" -Indent 1
			Write-Log -ErLevel Error -Message $error
		} else {
			Write-Log -Message "Installed" -Indent 1
		}
	} else {
		Write-Log -ErLevel Error -message "$DestFile does not exist. Unable to proceed." -Indent 1
	}
} # end function New-ProgramInstallation
function Write-Log {
	<#
	.SYNOPSIS
		Extensive function to write data to either the console screen, a log file, and/or a Windows event log.

	.DESCRIPTION
		Extensive function to write data to either the console screen, a log file, and/or a Windows event log. Data can be written as info, warning, error, and includes indentation, time stamps, etc.

	.NOTES
	  Version							: 2.7
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		:
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		: Test for log names and sources
													http://powershell.com/cs/blogs/tips/archive/2013/06/10/testing-event-log-names-and-sources.aspx
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param(
		# The type of message to be logged. Alias is 'type'.
		[Parameter(Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		#[ValidateSet("Error", "Warn", "Info")]
		[ValidateNotNullOrEmpty()]
		[string] $ErLevel = "Info",

		# The message to be logged.
		[Parameter(Position = 1, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No message specified.")]
		[ValidateNotNullOrEmpty()]
		[string] $Message,

		# Specifies that $message should not the sent to the log file.
		[Parameter(Position = 2, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $NoLog,

		# Specifies to not display the message to the console.
		[Parameter(Position = 3, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[switch] $NoConsole,

		# The number of spaces to indent the message in the log file.
		[Parameter(Position = 4, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateRange(1,30)]
		[ValidateNotNullOrEmpty()]
		[Int16] $Indent = 0,

		# Specifies what color the text should be be displayed on the console. Ignored when switch 'NoConsoleOut' is specified.
		[Parameter(Position = 5, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateSet("Black", "DarkMagenta", "DarkRed", "DarkBlue", "DarkGreen", "DarkCyan", "DarkYellow", "Red", "Blue", "Green", "Cyan", "Magenta", "Yellow", "DarkGray", "Gray", "White")]
		[ValidateNotNullOrEmpty()]
		[String] $ConsoleForeground = 'White',

		# Existing log file is deleted when this is specified. Alias is 'Overwrite'.
		[Parameter(Position = 6, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[Switch] $Clobber,

		# The name of the system event log, e.g. 'Application'. Note that writing to the system event log requires elevated permissions.
		[Parameter(Position = 7, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateSet("Application","System","Security","Lync Server","Microsoft Office Web Apps")]
		[ValidateNotNullOrEmpty()]
		[String] $EventLogName = "Application",

		# The name to appear as the source attribute for the system event log entry. This is ignored unless 'EventLogName' is specified.
		[Parameter(Position = 8, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateNotNullOrEmpty()]
		[String] $EventSource = $($MyInvocation.ScriptName).Name,

		# The ID to appear as the event ID attribute for the system event log entry. This is ignored unless 'EventLogName' is specified.
		[Parameter(Position = 9, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateRange(1,65535)]
		[ValidateNotNullOrEmpty()]
		[Int32] $EventID = 1,

		# The text encoding for the log file. Default is ASCII.
		[Parameter(Position = 10, ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true)]
		[ValidateSet("Unicode","Byte","BigEndianUnicode","UTF8","UTF7","UTF32","ASCII","Default","OEM")]
		[ValidateNotNullOrEmpty()]
		[String] $LogEncoding = "ASCII"
	)
	try {
		[string]$LogFolder = Split-Path $LogPath -Parent
		if (-not(Test-Path $LogFolder)){New-Item $LogFolder -type Directory | Out-Null}
		$msg = "{0} : {1} : {2}{3}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $ErLevel.ToUpper(), ("  " * $Indent), $Message
		if (-not($NoConsole)){
			switch ($ErLevel) {
				"Error" {$Host.UI.WriteErrorLine("$Message")}
				"Warn" {Write-Warning $Message}
				"Info" {Write-Host $Message -ForegroundColor $ConsoleForeground}
			}
		}
		if (-not($NoLog)){
			if ($Clobber) {
				$msg | Out-File -FilePath $LogPath -Encoding $LogEncoding -Force
			} else {
				$msg | Out-File -FilePath $LogPath -Encoding $LogEncoding -Append
			}
		}

		# http://social.technet.microsoft.com/Forums/en-US/winserverpowershell/thread/e172f039-ce88-4c9f-b19a-0dd6dc568fa0/

		if ($EventLogName) {
			if (-not $EventSource) {
				[string] $EventSource = $([IO.FileInfo] $MyInvocation.ScriptName).Name
			}

			if(-not [Diagnostics.EventLog]::SourceExists($EventSource)) {
				[Diagnostics.EventLog]::CreateEventSource($EventSource, $EventLogName)
	    }

			switch ($ErLevel) {
				"Error" {$EntryType = "Error"}
				"Warn"  {$EntryType = "Warning"}
				"Info"  {$EntryType = "Information"}
				Default  {$EntryType = "Information"}
			}
			Write-EventLog -LogName $EventLogName -Source $EventSource -EventId 1 -EntryType $EntryType -Message $Message
		}
		$msg = ""
	}
	catch {
		Throw "Failed to create log entry in: '$LogPath'. The error was: '$_'."
	}
} # end function Write-Log
function Test-IsProxyEnabled {
	<#
	.SYNOPSIS
		Determines (the best it can) if a proxy is in place for Internet access.

	.DESCRIPTION
		Determines (the best it can) if a proxy is in place for Internet access. If so, other functions that download files can better handle downloads.

	.NOTES
	  Version							: 1.1
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param ()
	Write-Log -Message "Checking if a proxy is enabled" -NoConsole -Indent 1
	# If this registry key doesn't exist at all, it's because IE has never been launched. We need to create it here so that download attempts and proxy checks don't throw a silent error
	if ((Get-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").Property -notcontains "ProxyEnable"){
		Write-Log -Message "Internet Explorer has never been opened. Proxy registry values have yet to be set. Setting it to 0 now." -NoConsole -Indent 1
		New-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyEnable -Value 0 | Out-Null
	}
	if ((Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -name ProxyEnable -ErrorAction SilentlyContinue).ProxyEnable -ne 0){
		Write-Log -Message "A proxy is required" -NoConsole -Indent 2
		[string]$ProxyServer = (Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -name ProxyServer).ProxyServer
		Write-Log -Message "Configured proxy: `"$ProxyServer`"" -NoConsole -Indent 2

		if (-not($PSDefaultParameterValues.ContainsKey("Start-BitsTransfer:ProxyAuthentication"))){
			Write-Log -Message "Prompting for credentials" -NoConsole -Indent 2
			$ProxyCredentials = Get-Credential -Message "Enter Proxy authentication credentials for $ProxyServer" -UserName "${env:USERDOMAIN}\${env:UserName}"
    	if ($ProxyCredentials){
    		Write-Log -Message "Credentials entered" -NoConsole -Indent 2
    		Write-Log -Message "Adding default values for Start-BitsTransfer" -NoConsole -Indent 2
    		Write-Log -Message "Adding default value for ProxyAuthentication - `"Basic`"" -NoConsole -Indent 2
    		$PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyAuthentication","Basic")
    		$ProxyUserName = $ProxyCredentials.username
    		Write-Log -Message "Adding default value for ProxyCredential - `"$ProxyUserName`"" -NoConsole -Indent 2
    		$PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyCredential",$ProxyCredentials)
    		# Write-Log -Message "Adding default value for ProxyList - `"$ProxyServer`"" -NoConsole -Indent 1
    		# $PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyList",$ProxyServer)
    		# Write-Log -Message "Adding default value for ProxyUsage - `"AutoDetect`"" -NoConsole -Indent 1
    		# $PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyUsage","AutoDetect")
			} else {
				Write-Log -ErLevel Error -message "Credentials NOT entered. Following commands will likely fail" -NoConsole -Indent 2
			}
    }
	} else {
		Write-Log -Message "Proxy is not enabled" -NoConsole -Indent 2
		# Clear the error queue in case the proxy registry key didn't exist at all and threw an error.
		$error.clear()
	}
} # end function Test-IsProxyEnabled
function New-Popup {
	<#
	.Synopsis
		Display a Popup Message

	.Description
		This command uses the Wscript.Shell PopUp method to display a graphical message
		box. You can customize its appearance of icons and buttons. By default the user
		must click a button to dismiss but you can set a timeout value in seconds to
		automatically dismiss the popup.

		The command will write the return value of the clicked button to the pipeline:
		  OK     = 1
		  Cancel = 2
		  Abort  = 3
		  Retry  = 4
		  Ignore = 5
		  Yes    = 6
		  No     = 7

		If no button is clicked, the return value is -1.

	.Example
	PS C:\> new-popup -message "The update script has completed" -title "Finished" -time 5

	This will display a popup message using the default OK button and default
	Information icon. The popup will automatically dismiss after 5 seconds.

	.Notes
		Last Updated: April 8, 2013
		Version     : 1.0

	.Inputs
		None

	.Outputs
		integer

		Null   = -1
		OK     = 1
		Cancel = 2
		Abort  = 3
		Retry  = 4
		Ignore = 5
		Yes    = 6
		No     = 7
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	Param (
		# Message to be displayed in the popup message dialog box.
		[Parameter(Position = 0, Mandatory = $True, HelpMessage = "Enter a message for the popup")]
		[ValidateNotNullorEmpty()]
		[string] $Message,

		# Title of the popup dialog box.
		[Parameter(Position = 1, Mandatory = $True, HelpMessage = "Enter a title for the popup")]
		[ValidateNotNullorEmpty()]
		[string] $Title,

		# If defined, automatically dismisses the dialog box after the specified number of seconds. Defaults to 0, which requires a mouse click.
		[Parameter(Position = 2, HelpMessage = "How many seconds to display? Use 0 require a button click.")]
		[ValidateScript({$_ -ge 0})]
		[int] $Time = 0,

		# Type of buttons to display.
		[Parameter(Position = 3, HelpMessage = "Enter a button group")]
		[ValidateNotNullorEmpty()]
		[ValidateSet("OK","OKCancel","AbortRetryIgnore","YesNo","YesNoCancel","RetryCancel")]
		[string] $Buttons = "OK",

		# Icon set to use in dialog box.
		[Parameter(Position = 4, HelpMessage = "Enter an icon set")]
		[ValidateNotNullorEmpty()]
		[ValidateSet("Stop","Question","Exclamation","Information" )]
		[string] $Icon = "Information"
	)

	#convert buttons to their integer equivalents
	Switch ($Buttons) {
		"OK"               {$ButtonValue = 0}
		"OKCancel"         {$ButtonValue = 1}
		"AbortRetryIgnore" {$ButtonValue = 2}
		"YesNo"            {$ButtonValue = 4}
		"YesNoCancel"      {$ButtonValue = 3}
		"RetryCancel"      {$ButtonValue = 5}
	}

	#set an integer value for Icon type
	Switch ($Icon) {
		"Stop"        {$iconValue = 16}
		"Question"    {$iconValue = 32}
		"Exclamation" {$iconValue = 48}
		"Information" {$iconValue = 64}
	}

	#create the COM Object
	Try {
	  $wshell = New-Object -ComObject Wscript.Shell -ErrorAction Stop
	  #Button and icon type values are added together to create an integer value
	  $wshell.Popup($Message,$Time,$Title,$ButtonValue+$iconValue)
	}

	Catch {
	  #You should never really run into an exception in normal usage
	  Write-Log -ErLevel Warn -message "Failed to create Wscript.Shell COM object"
	  Write-Log -ErLevel Warn -message $_.exception.message
	}
} # end function New-Popup
function Set-ModuleStatus {
	<#
	.SYNOPSIS
		Imports a specified PowerShell module, with error checking.

	.DESCRIPTION
		Imports a specified PowerShell module, with error checking.

	.NOTES
	  Version							: 1.5
		Wish list						: Better error trapping
	  Rights Required			: None
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param	(
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No module name specified!")]
		[ValidateNotNullOrEmpty()]
		[string] $name
	)
	PROCESS{
		# Executes once for each pipeline object
		# the $_ variable represents the current input object
		if (-not(Get-Module -name "$name")) {
			if (Get-Module -ListAvailable | Where-Object Name -eq "$name") {
				Import-Module -Name "$name"
				# module was imported
				# return $true
			} else {
				# module was not available
				# return $false
			}
		} else {
			# Write-Output "$_ module already imported"
			# return $true
		}
	} # end PROCESS
} # end function Set-ModuleStatus
function Test-IsRebootRequired	{ # http://technet.microsoft.com/en-us/library/cc164360(v=EXCHG.80).aspx
	<#
	.SYNOPSIS
		Looks for key indicators that a restart is required on the local machine.

	.DESCRIPTION
		Looks for key indicators that a restart is required on the local machine. This is done by checking known registry keys, as well as some variables set within the script itself. It returns a true/false.

	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: None
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param()
	if ((Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue) -or (Test-Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") -or (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name rebootrequired -ErrorAction SilentlyContinue) -or $RestartRequired){
		$RestartNeeded = $true
		return $true
	}
} # end function Test-IsRebootRequired

# Main Functions

function Set-PowerPlan {
	<#
	.SYNOPSIS
		Configures the Power Plan on the local machine. Called from Set-HighPower.

	.DESCRIPTION
		Configures the Power Plan on the local machine. Called from Set-HighPower.

	.NOTES
	  Version							: 1.2
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:	http://www.ehloworld.com/2558
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK
		http://www.ehloworld.com/2558

	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param (
		# Defines the power plan the set the computer to
		[ValidateSet("High performance", "Balanced", "Power saver")]
		[ValidateNotNullOrEmpty()]
		[string] $PreferredPlan = "High Performance"
	)

	Write-Log -Message "Setting power plan to `"$PreferredPlan`"" -NoConsole -Indent 1
	$guid = (Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "ElementName='$PreferredPlan'").InstanceID.ToString()
	$regex = [regex]"{(.*?)}$"
	$plan = $regex.Match($guid).groups[1].value

	powercfg -S $plan
	$Output = "Power plan set to "
	$Output += "`"" + ((Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "IsActive='$True'").ElementName) + "`""
	Write-Log -Message $Output -NoConsole -Indent 1
} # end function Set-PowerPlan

function Set-PrimaryDNSSuffix {
	<#
	.SYNOPSIS


	.DESCRIPTION


	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:	http://www.ehloworld.com/2558
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE


	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param ()
	if ((Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name Domain).Domain -notmatch "([A-Za-z0-9-]{2,63}\.\w{2,63}\.\w{2,63}|\w{2,63}\.\w{2,63})$"){
		[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
		do {
			Write-Log -Message "Prompting for primary DNS suffix" -NoConsole -Indent 1
			$DomainSuffix = [Microsoft.VisualBasic.Interaction]::InputBox("Enter primary domain suffix", "Computer name/domain changes", "")
		}while(
			$DomainSuffix -notmatch "([A-Za-z0-9-]{2,63}\.\w{2,63}\.\w{2,63}|\w{2,63}\.\w{2,63})$"
		)
		if ($DomainSuffix){
			Write-Log -Message "User entered $DomainSuffix" -NoConsole -Indent 1
			Write-Log -Message "Adding $DomainSuffix to $env:ComputerName" -NoConsole -Indent 1
			netdom computername $env:ComputerName /add:$env:ComputerName.$DomainSuffix
			Write-Log -Message "Making $DomainSuffix the primary name" -NoConsole -Indent 1
			netdom computername $env:ComputerName /makeprimary:$env:ComputerName.$DomainSuffix | Out-Null
			$RestartRequired = $true
		}
		if ($RestartRequired){
			Write-Log -ErLevel Warn -Message "Restart is required" -NoConsole -Indent 1
			Write-Log -ErLevel Warn -Message "Prompting for restart" -NoConsole -Indent 1
			if ((New-Popup -Message "Successfully changed the primary name for the computer. The computer must be rebooted for this name change to take effect. The specified new name was removed from the list of alternate computer names. The primary computer name will be set to the specified new name after the reboot. Restart now?" -Title "Computer name/domain changes" -Buttons YesNo -Icon Question) -eq 6){
				Write-Log -Message "User chose to reboot" -NoConsole
				Stop-Script -reboot
			} else {
				Write-Log -ErLevel Warn -Message "User chose NOT to reboot" -NoConsole
				Stop-Script
			}
		}
	}else{
		Write-Log -ErLevel Warn -Message "Primary DNS suffix already configured"
	}
} # end function Set-PrimaryDNSSuffix

function Install-SilverLight {
	<#
	.SYNOPSIS
		Installs Microsoft SilverLight on the local machine.

	.DESCRIPTION
		Installs Microsoft SilverLight on the local machine.

	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param()
	Write-Log -Message "Installing Microsoft Silverlight"
	Write-Log -Message "Checking if Silverlight is already installed" -NoConsole
	if (-not(Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}")){
		Write-Log -Message "Silverlight is not installed" -NoConsole -Indent 1
		New-FileDownload $URLsilverlight
		New-ProgramInstallation -InstallFile "$TargetFolder\$($URLsilverlight | Split-Path -leaf)" -InstallSwitches "/q" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}"
		# remove pinned shortcut on desktop to "C:\Program Files\Microsoft Silverlight\5.1.10411.0\Silverlight.Configuration.exe"
	} else {
		Write-Log -Message "Silverlight already installed" -Indent 1
	}
} # end function Install-SilverLight

function Install-VisualCRedist {
	<#
	.SYNOPSIS
		Installs Microsoft Visual C Redist on the local machine.

	.DESCRIPTION
		Installs Microsoft Visual C Redist on the local machine.

	.NOTES
	  Version							: 1.0
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Clive Graven - All Rights Reserved
	  Email/Blog/Twitter	: cliveg@microsoft.com 	@cliveag
	  Dedicated Post			:
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK


	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param()
	Write-Log -Message "Installing Microsoft Silverlight"
	Write-Log -Message "Checking if Silverlight is already installed" -NoConsole
	if (-not(Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}")){
		Write-Log -Message "Silverlight is not installed" -NoConsole -Indent 1
		New-FileDownload $URLsilverlight
		New-ProgramInstallation -InstallFile "$TargetFolder\$($URLsilverlight | Split-Path -leaf)" -InstallSwitches "/q" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}"
	#New-ProgramInstallation -InstallFile "$TargetFolder\$($URLstressandperformancetool | Split-Path -leaf)" -InstallSwitches "/qb" -WaitForRegistryEntry "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\$GUID2013stressperformancetool" -WaitForProcessName "CapacityPlanningTool.msi"
		# remove pinned shortcut on desktop to "C:\Program Files\Microsoft Silverlight\5.1.10411.0\Silverlight.Configuration.exe"
	} else {
		Write-Log -Message "Silverlight already installed" -Indent 1
	}
} # end function Install-VisualCRedist


#endregion Functions
